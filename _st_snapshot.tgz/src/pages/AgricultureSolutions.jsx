import { useEffect } from 'react';
import AgriHero from '../components/sections/agri/AgriHero.jsx';
import AgriChallenge from '../components/sections/agri/AgriChallenge.jsx';
import AgriBenefits from '../components/sections/agri/AgriBenefits.jsx';
import AgriModules from '../components/sections/agri/AgriModules.jsx';
import AgriStats from '../components/sections/agri/AgriStats.jsx';
import AgriResources from '../components/sections/agri/AgriResources.jsx';
import AgriCta from '../components/sections/agri/AgriCta.jsx';
import Certifications from '../components/sections/Certifications.jsx';
import Testimonials from '../components/sections/Testimonials.jsx';
import { agriMeta } from '../data/agriculture.js';
import '../styles/pages/agriculture.css';

export default function AgricultureSolutions() {
  useEffect(() => {
    document.title = agriMeta.title;
    document.querySelector('meta[name="description"]')?.setAttribute('content', agriMeta.description);
  }, []);

  return (
    <>
      <AgriHero />
      <div className="light-band">
        <AgriChallenge />
      </div>
      <AgriBenefits />
      <AgriModules />
      <AgriStats />
      <Certifications />
      <Testimonials />
      <AgriResources />
      <AgriCta />
    </>
  );
}
