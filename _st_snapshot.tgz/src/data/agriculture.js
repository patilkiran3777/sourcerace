/**
 * Copy for the Agriculture Solutions inner page (/agriculture-solutions).
 * Module and benefit names follow sourcetrace.com/agriculture-solutions;
 * descriptions are tightened for scanning. Edit text here, not in components.
 */
import {
  Sprout, Warehouse, Factory, Store,
  Smartphone, Monitor, Handshake,
  Globe, Eye, Route, Activity, PiggyBank, ShieldCheck, Boxes, TrendingUp,
  UserPlus, IdCard, MapPinned, Map, Package, Megaphone, Truck,
  Wallet, ScanBarcode, BadgeCheck, BarChart3, LayoutDashboard,
} from 'lucide-react';
import { asset } from './asset.js';
import { ROUTES, stats } from './content.js';

const img = (p) => asset(`/images/${p}.webp`);

export const agriMeta = {
  title: 'Agriculture Management Solutions | SourceTrace DATAGREEN',
  description:
    'SourceTrace DATAGREEN traces produce from remote farms to processing and retail: farmer enrolment, plot mapping, input distribution, procurement, certification and real-time analytics.',
};

export const agriHero = {
  breadcrumb: [
    { label: 'Home', href: '/' },
    { label: 'Solutions', href: ROUTES.solutions },
    { label: 'Agriculture Solutions' },
  ],
  eyebrow: 'DATAGREEN · Agriculture Solutions',
  titleLines: [
    ['Agriculture', 'Management', 'Solutions,'],
    ['From', 'Field', 'To', 'Retail.'],
  ],
  markFrom: 'Field', // lime words + hand-drawn underline start here
  text:
    'Tracing produce from remote fields to the retail shelf is hard. SourceTrace DATAGREEN is a single traceability solution that follows your goods from source to central processing, even in the most remote regions.',
  primary: { label: 'Request a Demo', href: ROUTES.demo },
  secondary: { label: 'Explore the modules', href: '#modules' },
  image: img('hero/hero-field'),
  journey: [
    { label: 'Farm', note: 'Enrol & map', icon: Sprout },
    { label: 'Collection', note: 'Procure & pay', icon: Warehouse },
    { label: 'Processing', note: 'Transfer & stock', icon: Factory },
    { label: 'Market', note: 'Trace & certify', icon: Store },
  ],
};

export const agriChallenge = {
  eyebrow: 'The challenge',
  title: "Every Shipment Starts In A Field You Can't See.",
  accentFrom: 5,
  text:
    'Smallholder supply is spread across thousands of farms, agents and collection points, often with no connectivity. DATAGREEN captures every touchpoint at the source and connects it to your processing, certification and sales teams.',
  stack: [
    { icon: Smartphone, title: 'Mobile data-collection apps', text: 'Offline capture for field staff, agents and farmers.' },
    { icon: Monitor, title: 'Web analytics dashboard', text: 'Reports, controls and maps for managers.' },
    { icon: Handshake, title: 'Value-chain collaboration', text: 'Share verified data with buyers, certifiers and partners.' },
  ],
  image: img('platform/tablet'),
  imageAlt: 'Tablet showing a farm dashboard held up in a crop field',
  record: {
    kicker: 'Sample farmer record',
    id: 'FR-20481 · Smallholder',
    items: ['Profile & family group', 'Plot mapped · 2.4 ha', 'GPS & photo verified'],
  },
  sync: 'Captured offline · syncs on connect',
};

export const agriBenefits = {
  eyebrow: 'Outcomes',
  title: 'What Changes When Your Supply Chain Runs On DATAGREEN.',
  accentFrom: 6,
  text: 'One shared record from farm to buyer gives every team the same picture, and removes the paperwork that slows it down.',
  items: [
    { icon: Globe, title: 'Global visibility', text: 'See operations and supply across every region in one view.' },
    { icon: Eye, title: 'Greater transparency', text: 'Every transaction carries who, where and when.' },
    { icon: Route, title: 'Source traceability', text: 'Follow each lot back to the farm and plot it came from.' },
    { icon: Activity, title: 'Near real-time BI', text: 'Field data reaches dashboards as soon as devices sync.' },
    { icon: PiggyBank, title: 'Lower operational costs', text: 'Replace paper registers and repeat field visits.' },
    { icon: ShieldCheck, title: 'Stronger internal controls', text: 'Audit trails and approvals at every step.' },
    { icon: Boxes, title: 'Better resource management', text: 'Put inputs, staff and transport where they are needed.' },
    { icon: TrendingUp, title: 'Capacity to grow', text: 'Add farmers, crops and regions on the same platform.' },
  ],
};

/* Twelve modules grouped by where they sit in the season, so buyers can find
   "their" part of the value chain instead of scanning a flat list of 12. */
export const agriModules = {
  eyebrow: 'DATAGREEN agri solution modules',
  title: 'Twelve Modules. One Record From Farm To Buyer.',
  accentFrom: 2,
  text: 'Use the modules your operation needs. Every one writes to the same farmer, plot and lot record, so nothing is keyed in twice.',
  cta: { label: 'Request a Demo', href: ROUTES.demo },
  phases: [
    {
      id: 'onboard', name: 'Onboard', text: 'Know every farmer and every plot.',
      modules: [
        { icon: UserPlus, title: 'Farmer Enrollment', text: 'Capture smallholder profiles, family groups, farms and crops in one database, verified with GPS and photos.', tags: ['GPS', 'Photos', 'Offline'] },
        { icon: IdCard, title: 'Farmer Data Management', text: 'Create and update farmer profiles on the web and see every farm location on a digital map.', tags: ['Web profiles', 'Map view'] },
        { icon: MapPinned, title: 'Geo Plotting & Crop Monitoring', text: 'Log field visits with GPS, photos and notes, and follow staff activity and crop progress.', tags: ['Field visits', 'Crop stages'] },
        { icon: Map, title: 'Digital Mapping', text: 'Visualise farm locations, crop areas, neighbouring farms, field staff and geo-referenced transactions.', tags: ['GIS', 'Geo-tagged'] },
      ],
    },
    {
      id: 'operate', name: 'Operate', text: 'Support farmers through the season.',
      modules: [
        { icon: Package, title: 'Input Distribution', text: 'Track fertiliser, seed and pesticide from warehouse to farm. Monitor stock, record price and quantity, calculate production cost and manage farmer accounts.', tags: ['Stock', 'Cost of production', 'Farmer accounts'] },
        { icon: Megaphone, title: 'Advisory Services', text: 'Send voice and text advisories to field staff, and let farmers share observations by voice message.', tags: ['Voice', 'Text'] },
        { icon: Truck, title: 'Harvest Planning & Product Transfer', text: 'Estimate yield, capture pre- and post-harvest data, see remote stock and track transport and inventory.', tags: ['Yield estimate', 'Transport', 'Inventory'] },
      ],
    },
    {
      id: 'trade', name: 'Trade & Trace', text: 'Buy, certify and prove origin.',
      modules: [
        { icon: Wallet, title: 'Procurement & Payment', text: 'Record purchases at source with quality, quantity and price. Shorten payment cycles and pay farmers by direct bank transfer through payment gateways.', tags: ['Quality', 'Direct transfer'] },
        { icon: ScanBarcode, title: 'Agriculture Traceability (e-Traceability)', text: 'Farm-to-fork traceability with unique IDs, GS1 GLN data, SSCC labels and barcode or QR scanning.', tags: ['GS1 GLN', 'SSCC', 'QR'] },
        { icon: BadgeCheck, title: 'Certification (ICS)', text: 'Digitise your Internal Control System: inspections, farmer training and non-conformities for Fairtrade, GAP, GMP and Organic.', tags: ['Fairtrade', 'GAP', 'Organic'] },
      ],
    },
    {
      id: 'insight', name: 'Insight', text: 'Decide with live data.',
      modules: [
        { icon: BarChart3, title: 'In-built Real-Time Analytics', text: 'Reports at farmer, group, regional or global level on farmers, transactions, transport, certification and crop stages.', tags: ['Drill-down', 'Reports'] },
        { icon: LayoutDashboard, title: 'Executive Dashboard', text: 'Key indicators in charts, harvest progress against previous seasons, device and field-staff management, and over-the-air app updates.', tags: ['KPIs', 'OTA updates'] },
      ],
    },
  ],
};

/* Re-uses the homepage figures so the numbers stay in one place. */
export const agriStats = {
  title: 'Built In The Field, Proven At Scale.',
  items: stats.filter((s) => s.count).map((s) => ({ id: s.id, value: s.count, suffix: s.suffix, label: s.label })),
};

export const agriResources = {
  eyebrow: 'Resources',
  title: 'See DATAGREEN At Work.',
  accentFrom: 1,
  items: [
    { type: 'Case study', title: 'Fruitmaster Agro Fresh Pvt. Ltd.', text: 'How an Indian fresh-produce exporter runs its sourcing on SourceTrace.', cta: 'Read case study', href: `${ROUTES.caseStudies}/fruitmaster`, image: img('first-mile/farmers') },
    { type: 'Media', title: '“This will be the decade of Indian AgriTech”', text: 'SourceTrace in PC Quest on where Indian agritech is heading.', cta: 'Read article', href: '/media', image: img('hero/hero-aerial') },
    { type: 'Whitepaper', title: 'SourceTrace in 2022', text: 'Our whitepaper on digital traceability for agri-food value chains.', cta: 'Download whitepaper', href: '/white-paper', image: img('platform/farm-data') },
  ],
};

export const agriCta = {
  eyebrow: 'Get started',
  title: 'Bring Your Whole Value Chain Into View.',
  accentFrom: 3,
  text: 'See DATAGREEN set up for your crops, regions and certification programmes.',
  primary: { label: 'Request a Demo', href: ROUTES.demo },
  secondary: { label: 'Contact us', href: ROUTES.contact },
  image: img('hero/hero-aerial'),
};
