import { agriModules as m } from '../../../data/agriculture.js';
import SplitText from '../../ui/SplitText.jsx';
import Button from '../../ui/Button.jsx';
import useSectionReveal from '../../../hooks/useSectionReveal.js';
import { gsap, ScrollTrigger, MQ } from '../../../animations/gsapConfig.js';
import { onSpotlight } from '../../ui/spotlight.js';

const pad = (n) => String(n).padStart(2, '0');

export default function AgriModules() {
  const ref = useSectionReveal((root) => {
    const q = gsap.utils.selector(root);
    const mm = gsap.matchMedia();

    mm.add(MQ.motion, () => {
      q('.ag-phase').forEach((phase) => {
        const st = { trigger: phase.querySelector('.ag-phase__cards'), start: 'top 85%', once: true };
        gsap.from(phase.querySelectorAll('.ag-module'), { y: 90, autoAlpha: 0, duration: 1.2, ease: 'expo.out', stagger: 0.1, scrollTrigger: st });
        gsap.from(phase.querySelectorAll('.ag-module__icon'), { scale: 0, rotate: -90, duration: 0.8, ease: 'back.out(2)', stagger: 0.1, delay: 0.3, scrollTrigger: st });
      });
    });

    // Sticky index: highlight the phase in view and fill the progress rail with the scroll.
    const links = q('.ag-index__item');
    const phaseTriggers = q('.ag-phase').map((phase, i) =>
      ScrollTrigger.create({
        trigger: phase, start: 'top 55%', end: 'bottom 55%',
        onToggle: (self) => { if (self.isActive) links.forEach((l, j) => l.classList.toggle('is-active', j === i)); },
      }),
    );
    const progress = gsap.fromTo(q('.ag-index__progress i'), { scaleY: 0 }, {
      scaleY: 1, ease: 'none',
      scrollTrigger: { trigger: q('.ag-modules__list')[0], start: 'top 55%', end: 'bottom 55%', scrub: true },
    });
    // The card crossing the middle of the viewport becomes "active".
    const cardTriggers = q('.ag-module').map((card) =>
      ScrollTrigger.create({ trigger: card, start: 'top 65%', end: 'bottom 35%', toggleClass: { targets: card, className: 'is-active' } }),
    );

    return () => {
      mm.revert();
      progress.scrollTrigger?.kill();
      progress.kill();
      [...phaseTriggers, ...cardTriggers].forEach((t) => t.kill());
    };
  });

  let n = 0;
  return (
    <section className="ag-modules" id="modules" ref={ref} aria-labelledby="ag-modules-title">
      <div className="container">
        <div className="ag-head">
          <div>
            <p className="eyebrow ag-eyebrow ag-eyebrow--dark" data-reveal="">{m.eyebrow}</p>
            <SplitText as="h2" id="ag-modules-title" className="h2" text={m.title} accentFrom={m.accentFrom} />
          </div>
          <p className="body-lg ag-head__text" data-reveal="">{m.text}</p>
        </div>

        <div className="ag-modules__layout">
          <aside className="ag-index" aria-label="Module phases">
            <p className="ag-index__label">{m.phases.length} phases · {m.phases.reduce((t, p) => t + p.modules.length, 0)} modules</p>
            <div className="ag-index__track">
              <span className="ag-index__progress" aria-hidden="true"><i /></span>
              <ol>
                {m.phases.map((p, i) => (
                  <li className={`ag-index__item ${i === 0 ? 'is-active' : ''}`} key={p.id}>
                    <a href={`#phase-${p.id}`}>
                      <span className="ag-index__num">{pad(i + 1)}</span>
                      <span>
                        <strong>{p.name}</strong>
                        <small>{p.modules.map((x) => x.title.replace(/ \(.*\)/, '')).join(' · ')}</small>
                      </span>
                    </a>
                  </li>
                ))}
              </ol>
            </div>
            <Button href={m.cta.href}>{m.cta.label}</Button>
          </aside>

          <div className="ag-modules__list">
            {m.phases.map((p, pi) => (
              <div className="ag-phase" id={`phase-${p.id}`} key={p.id}>
                <header className="ag-phase__head">
                  <p className="ag-phase__tag" data-reveal="">Phase {pad(pi + 1)}</p>
                  <h3 className="ag-phase__title" data-reveal="">{p.name}</h3>
                  <p className="ag-phase__text" data-reveal="">{p.text}</p>
                  <span className="ag-phase__rule" aria-hidden="true" data-reveal-line="" />
                </header>
                <ul className="ag-phase__cards">
                  {p.modules.map(({ icon: Icon, title, text, tags }) => {
                    n += 1;
                    return (
                      <li className="ag-module" key={title} onPointerMove={onSpotlight}>
                        <div className="ag-module__top">
                          <span className="ag-module__icon"><Icon size={24} strokeWidth={1.6} aria-hidden="true" /></span>
                          <span className="ag-module__num" aria-hidden="true">{pad(n)}</span>
                        </div>
                        <h4 className="ag-module__title">{title}</h4>
                        <p className="ag-module__text">{text}</p>
                        <ul className="ag-module__tags" aria-label="Highlights">
                          {tags.map((t) => <li key={t}>{t}</li>)}
                        </ul>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
