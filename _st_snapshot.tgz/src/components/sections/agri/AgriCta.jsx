import { agriCta as c } from '../../../data/agriculture.js';
import SplitText from '../../ui/SplitText.jsx';
import Button from '../../ui/Button.jsx';
import useSectionReveal from '../../../hooks/useSectionReveal.js';
import { gsap, MQ } from '../../../animations/gsapConfig.js';

export default function AgriCta() {
  const ref = useSectionReveal((root) => {
    const mm = gsap.matchMedia();
    mm.add(MQ.motion, () => {
      // Panel opens out to full width as it scrolls up, like a window onto the field.
      gsap.fromTo(root.querySelector('.ag-cta__panel'),
        { clipPath: 'inset(8% 6% 8% 6% round 80px)' },
        { clipPath: 'inset(0% 0% 0% 0% round 60px)', ease: 'none',
          scrollTrigger: { trigger: root, start: 'top bottom', end: 'top 35%', scrub: true } });
    });
    return () => mm.revert();
  });

  return (
    <section className="ag-cta" ref={ref} aria-labelledby="ag-cta-title">
      <div className="container">
        <div className="ag-cta__panel">
          <div className="ag-cta__bg" aria-hidden="true"><img src={c.image} alt="" loading="lazy" data-parallax="14" /></div>
          <p className="eyebrow ag-eyebrow ag-eyebrow--dark" data-reveal="">{c.eyebrow}</p>
          <SplitText as="h2" id="ag-cta-title" className="h2" text={c.title} accentFrom={c.accentFrom} />
          <p className="ag-cta__text" data-reveal="">{c.text}</p>
          <div className="ag-cta__actions" data-reveal="">
            <Button href={c.primary.href}>{c.primary.label}</Button>
            <Button href={c.secondary.href} variant="outline-light">{c.secondary.label}</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
