import { agriResources as r } from '../../../data/agriculture.js';
import SplitText from '../../ui/SplitText.jsx';
import { ArrowRight } from '../../ui/Icons.jsx';
import useSectionReveal from '../../../hooks/useSectionReveal.js';

export default function AgriResources() {
  const ref = useSectionReveal();
  return (
    <section className="ag-resources" ref={ref} aria-labelledby="ag-resources-title">
      <div className="container">
        <p className="eyebrow ag-eyebrow" data-reveal="">{r.eyebrow}</p>
        <SplitText as="h2" id="ag-resources-title" className="h2" text={r.title} accentFrom={r.accentFrom} />
        <ul className="ag-resources__grid" data-reveal-group="">
          {r.items.map((it) => (
            <li className="ag-res" key={it.title}>
              <div className="ag-res__media">
                <img src={it.image} alt="" loading="lazy" width="640" height="400" />
                <span className="ag-res__type">{it.type}</span>
              </div>
              <div className="ag-res__body">
                <h3 className="ag-res__title"><a className="ag-res__link" href={it.href}>{it.title}</a></h3>
                <p className="ag-res__text">{it.text}</p>
                <span className="text-link" aria-hidden="true">{it.cta} <ArrowRight /></span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
