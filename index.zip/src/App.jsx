import Header from './components/layout/Header.jsx';
import Footer from './components/layout/Footer.jsx';
import MeetingTab from './components/layout/MeetingTab.jsx';
import Home from './pages/Home.jsx';

export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Header />
      <main id="main">
        <Home />
      </main>
      <Footer />
      <MeetingTab />
    </>
  );
}
