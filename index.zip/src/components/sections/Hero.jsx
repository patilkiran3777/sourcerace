import { Fragment, useRef } from 'react';
import { gsap, useGSAP, MQ } from '../../animations/gsapConfig.js';
import { hero } from '../../data/content.js';
import Button from '../ui/Button.jsx';
import ImpactStats from './ImpactStats.jsx';
import '../../styles/sections/hero.css';

export default function Hero() {
  const ref = useRef(null);
  const label = hero.titleLines.map((l) => l.join(' ')).join(' ');
  const markIndex = hero.titleLines[1].indexOf(hero.underlineFromWord);

  useGSAP(() => {
    const q = gsap.utils.selector(ref);
    const mm = gsap.matchMedia();

    mm.add(MQ.motion, () => {
      const tl = gsap.timeline({ defaults: { ease: 'expo.out' }, delay: 0.15 });
      tl.from(q('.hero__bg-media'), { scale: 1.18, duration: 2.6, ease: 'power3.out' }, 0)
        .from(q('.hero__title .split-word > span'), { yPercent: 115, duration: 1.3, stagger: 0.06 }, 0.15)
        .from(q('.hero__underline path'), { strokeDashoffset: 700, duration: 1.4, stagger: 0.18, ease: 'power3.inOut' }, 0.85)
        .from(q('.hero__text'), { y: 30, autoAlpha: 0, duration: 1.1 }, 0.7)
        .from(q('.hero__actions > *'), { y: 26, autoAlpha: 0, duration: 1, stagger: 0.1 }, 0.85)
        .from(q('.stat-card'), { y: 140, autoAlpha: 0, duration: 1.5, stagger: 0.08 }, 0.9);

      // Scroll: image drifts slower than the page, copy lifts away gently.
      gsap.to(q('.hero__bg-media'), {
        yPercent: 12, ease: 'none',
        scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: true },
      });
      gsap.to(q('.hero__content'), {
        y: -90, ease: 'none',
        scrollTrigger: { trigger: ref.current, start: 'top top', end: '60% top', scrub: true },
      });
    });

    // Bento depth: outer columns travel further than the centre one (desktop only).
    mm.add(MQ.desktop, () => {
      q('.stat-card').forEach((card) => {
        const depth = parseFloat(card.dataset.depth || 0);
        if (!depth) return;
        gsap.to(card, {
          y: -depth, ease: 'none',
          scrollTrigger: { trigger: q('.stats')[0], start: 'top 85%', end: 'bottom top', scrub: true },
        });
      });
    });

    return () => mm.revert();
  }, { scope: ref });

  return (
    <section className="hero" ref={ref} aria-labelledby="hero-title">
      <div className="hero__bg" aria-hidden="true">
        <img className="hero__bg-base" src={hero.backgroundBase} alt="" />
        <div className="hero__bg-media">
          <video src={hero.video} poster={hero.background} autoPlay muted loop playsInline preload="auto" />
        </div>
        <div className="hero__bg-shade" />
      </div>

      <div className="hero__content container">
        <h1 className="hero__title" id="hero-title" aria-label={label}>
          {hero.titleLines.map((line, li) => (
            <span className="split-line" key={li} aria-hidden="true">
              {li === 1 ? (
                <>
                  {line.slice(0, markIndex).map((w) => (
                    <Fragment key={w}><span className="split-word"><span>{w}</span></span>{' '}</Fragment>
                  ))}
                  <span className="hero__mark">
                    {line.slice(markIndex).map((w, i, arr) => (
                      <Fragment key={w}><span className="split-word"><span>{w}</span></span>{i < arr.length - 1 ? ' ' : ''}</Fragment>
                    ))}
                    <svg className="hero__underline" viewBox="0 0 636 16" preserveAspectRatio="none" aria-hidden="true">
                      <path d="M2 13.5 C 200 12.5, 420 9, 634 2" />
                      <path d="M2 13 L 634 13" />
                    </svg>
                  </span>
                </>
              ) : (
                line.map((w, i) => (
                  <Fragment key={w}><span className="split-word"><span>{w}</span></span>{i < line.length - 1 ? ' ' : ''}</Fragment>
                ))
              )}
            </span>
          ))}
        </h1>
        <p className="hero__text">{hero.text}</p>
        <div className="hero__actions">
          <Button href={hero.primary.href}>{hero.primary.label}</Button>
          <Button href={hero.secondary.href} variant="outline-light">{hero.secondary.label}</Button>
        </div>
      </div>

      <ImpactStats />
    </section>
  );
}
